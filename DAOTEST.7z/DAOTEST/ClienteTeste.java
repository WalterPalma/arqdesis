package DAOTEST;
import DAO.ClienteDAO;
import java.sql.Connection;
import org.junit.Before;
import org.junit.Test;
public class ClienteTeste {
   public static void main(String[] args) {
      ClienteDAO cliente = new Cliente();
      Connection conn;
      
  @Test
  public void efetuarSaque()
  {
	  assertTrue("Se sacar, deve ser TRUE", cliente.sacar(conn,"292456"), true);
	  assertTrue("Se sacar, deve ser TRUE", cliente.sacar(conn,"246853"), true);
	  assertTrue("Se sacar, deve ser TRUE", cliente.sacar(conn,"965428"), true);
  }
  
  @Test
  public void consultarExtrato()
  {
	  assertTrue("Se sair extrato, deve ser TRUE", cliente.extrato(conn,"292456", true);
	  assertTrue("Se sair extrato, deve ser TRUE", cliente.extrato(conn,"246853", true);
	  assertTrue("Se sair extrato, deve ser TRUE", cliente.extrato(conn,"965428", true);
  }
      
      
   }
}