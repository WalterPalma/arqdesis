package DAO
import DAO.ClienteDAO;
import java.sql.Connection;
public class ClienteTeste {
   public static void main(String[] args) {
      Cliente cliente = new Cliente();
      cliente.extrato(conn, "283743");
      cliente.sacar(conn,"283743", "50");
   }
}