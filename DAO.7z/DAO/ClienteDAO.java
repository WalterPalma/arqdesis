//CPF//Nome//Codigo//Agencia//Conta//Senha
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.ArrayList;
import javax.swing.*;
import projeto.model.Cliente;
import projeto.view.Saldo;

public class ClienteDAO
{
   private String cpf, nome;
   private String agencia, conta;
   private int codigo;
   private String senha;
   public String sData;
   
   Cliente c = new Cliente();
   
   public ClienteDAO()
   {
      codigo = c.getCodigo();
      cpf = c.getCpf();
      nome = c.getNome();
      agencia = c.getAgencia();
      conta = c.getConta();
      senha = c.getSenha();  
   }
   
   public void setData(String d)
   {
      sData = d;
   }
   
   
   //Inclus�o, Consulta, Altera��o e Exclus�o
   
   public String consultarSaldo(Connection conn, String cont)
   {
      String sqlSelect = "SELECT * FROM saldo WHERE conta = ? and data_saldo = ?";
      PreparedStatement stm = null;
      ResultSet rs = null;  
      String sConta = cont;
      String sA = "";
      
      
      try
      {
         stm = conn.prepareStatement(sqlSelect);
         stm.setString(1,sConta);
         stm.setString(2,sData);
         rs = stm.executeQuery();
         while(rs.next())
         {
            sA = rs.getString("saldo");
         }
         stm.close();         
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }   
      return sA;
   }
   
   public String consultarSaldoSolo(Connection conn, String cont)
   {
      String sqlSelect = "SELECT * FROM saldo WHERE conta = ? order by data_saldo";
      PreparedStatement stm = null;
      ResultSet rs = null;  
      String sConta = cont;
      String sA = "";
      
      
      try
      {
         stm = conn.prepareStatement(sqlSelect);
         stm.setString(1,sConta);
         rs = stm.executeQuery();
          while(rs.next())
          {
            sA = rs.getString("saldo");
         }
         stm.close();         
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }   
      System.out.println(sA);
      return sA;
   }

   
   public void Sacar(Connection conn, String cont, double valor)
   {
      String valorConta = consultarSaldoSolo(conn, cont);      
      double valorContaD = Double.parseDouble(valorConta);
      if(valor > valorContaD)
      {
         JOptionPane.showMessageDialog(null,"Saldo Insuficiente!");
      }
      else
      {
         double resultadoSaldo = valorContaD - valor;
         updateSaldo(conn, cont, resultadoSaldo);
         JOptionPane.showMessageDialog(null," Saque efetuado! Retire as C�dulas!");
      }
           
   }

   
   public void debAuto(Connection conn,String serv,String oper,String dat,String consum)
   {
      String sServ = "1";
      String sOper = oper;
      String sData = dat;
      String sConsum = consum;
      PreparedStatement stm = null;
       String sqlInsert = "INSERT INTO debauto(servico, operadora, data_deb, consumidor) VALUES(?, ?, ?, ?)";

     
      try
      {
         stm = conn.prepareStatement(sqlInsert); 
         stm.setString(1,sServ);
         stm.setString(2,sOper);
         stm.setString(3,sData);
         stm.setString(4,sConsum );
         stm.executeUpdate();   
         conn.commit();
                
         
         stm.close();    
         System.out.println("OK");      
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
           
      
   }
   
   public void transferir(Connection conn,String age,String con,double valor)
   {
      String sAg = age;
      String sCon = con;
      double dValor = valor; 
      String sqlInsert = "INSERT INTO transferencia(agencia,conta,valor, id_transf) VALUES (?, ?, ?, ?)";
      int idTrans = 1;
      PreparedStatement stm = null;
      try
      {
         stm = conn.prepareStatement(sqlInsert);
         stm.setString(1,sAg);
         stm.setString(2,sCon);
         stm.setDouble(3,dValor);
         stm.setInt(4,idTrans);
         stm.execute();
          conn.commit();
         
         stm.close();  
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
   
      System.out.println("teste ");
      
   }
   
   public void extrato(Connection conn, String cont)
   {
      //id_operacao, cpf, valor, data_ext
      String conta = cont;
      
      String sqlSelect = "SELECT * FROM extrato where conta = ?";
      PreparedStatement stm = null;
      ResultSet rs = null;  
      String sA = "****** Extrato ********\n";
      
      try
      {
         stm = conn.prepareStatement(sqlSelect);
         stm.setString(1,conta);
         rs = stm.executeQuery();
         while(rs.next())
         {           
            sA += "Data:  " +  rs.getString("data_ext") + "\n";
            sA += "Saldo: " +  rs.getString("saldo") + "\n";
            
         }
         stm.close();         
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
      
      JOptionPane.showMessageDialog(null,sA);
      
   }
   
   public void InsertExtrato(Connection conn, double sal, String dataExt)
   {
      String sqlInsert = "INSERT INTO extrato(saldo , data_ext) VALUES(?,?)";
      PreparedStatement stm = null;
      
      String sData = dataExt;
      double dSaldo = sal;
      
      try
      {
         stm = conn.prepareStatement(sqlInsert);
         stm.setDouble(1,dSaldo);
         stm.setString(2,sData);
         stm.execute();
      
         stm.close(); 
      }        
      catch(Exception e)
      {
         e.printStackTrace();
      }      
   
   }
   
   
   //cpf, id_operacao, saldo_disp ,saldo_mes
   public void updateSaldo(Connection conn,String cont, double sal)
   {
      String sqlInsert = "UPDATE saldo SET saldo = ? WHERE conta = ?";
      PreparedStatement stm = null;  
      String sConta = cont;
      double dSaldo = sal;   
      try
      {  
         stm.setDouble(1,dSaldo);
         stm.setString(2,sConta);
         stm.execute();
         stm.close(); 
      
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
   }
   
   
   
   
   
   
   public static void main(String args[])
   {
      ClienteDAO c = new ClienteDAO();
      Connection conn = null; 
       
      try
      {
         AcessoBD bd = new AcessoBD();
         conn = bd.obtemConexao();
         conn.setAutoCommit(false);
       //c.consultarSaldo(conn,"292427");
       //c.consultarSaldo(conn,"23498798712");
       //c.consultarSaldo(conn,"42340910230");
       
       
       
      //c.debAuto(conn,"42340910230","1","333333","20150303","3456");
        // c.transferir(conn,"2233","234329",12.0);
       // c.extrato(conn,"12309834429","20151111");
      }
      catch(Exception e)
      {
         e.printStackTrace();
      }
      
   }
   
   
   
   
  
   
   
}