package projeto.view;

import java.awt.Dimension;
import javax.swing.JLabel;

public class Rotulo extends JLabel {
	public Rotulo(String arg0) {
		super(arg0);
		setPreferredSize(new Dimension(150, 150));
	}
}