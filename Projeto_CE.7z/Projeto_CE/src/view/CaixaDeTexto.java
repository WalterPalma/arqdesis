package view;

import java.awt.Dimension;
import javax.swing.JTextField;

public class CaixaDeTexto extends JTextField {
	CaixaDeTexto() {
		setPreferredSize(new Dimension(200, 40));
	}
}
