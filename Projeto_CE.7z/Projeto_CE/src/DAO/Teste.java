package DAO;

import model.Cliente;
import To.ClienteTo;
import DAO.ClienteDAO;
//import javax.swing.JOptionPane;

public class Teste{

	public static void main(String args[]){
		Cliente cliente = new Cliente("Palma","2237","832914");
		cliente.criar();
		/*cliente.carregar();
		System.out.println(cliente);
		cliente.setAgencia("2239");
		cliente.atualizar();
		cliente.carregar();
		System.out.println(cliente);
		cliente.excluir();
		cliente.carregar();
		System.out.println(cliente);	*/	
	}
}
