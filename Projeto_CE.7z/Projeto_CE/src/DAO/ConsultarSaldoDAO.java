package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Factory.ConnectionFactory;
import To.ClienteTo;
import To.ConsultarSaldoTo;

public class ConsultarSaldoDAO {
	
	
	public String consultarSaldo(ConsultarSaldoTo to) {
		String sqlSelect = "SELECT * FROM saldo WHERE conta = ?";
		ResultSet rs = null;
		String sA = "";

		try (Connection conn = ConnectionFactory.obtemConexao();
			PreparedStatement stm = conn.prepareStatement(sqlSelect);){
			stm.setString(1, to.getConta());
			rs = stm.executeQuery();
			while (rs.next()) {
				sA = rs.getString("saldo");
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sA;
	}

}
