package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import To.ClienteTo;
import javax.swing.JOptionPane;
import Factory.ConnectionFactory;
import java.util.ArrayList;

public class ClienteDAO {
	

	
	//CRUD - Cliente	
	public void incluir(ClienteTo to) {
		String sqlInsert = "INSERT INTO cliente(nome, agencia, conta) VALUES(?, ?, ?)";
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setString(1, to.getNome());
			stm.setString(2, to.getAgencia());
			stm.setString(3, to.getConta());
			stm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void atualizar(ClienteTo to) {
		String sqlUpdate = "UPDATE cliente SET nome=?, agencia=? WHERE conta=?";
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
			stm.setString(1, to.getNome());
			stm.setString(2, to.getAgencia());
			stm.setString(3, to.getConta());
			stm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void excluir(ClienteTo to) {
		String sqlDelete = "DELETE FROM cliente WHERE conta = ?";
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
			stm.setString(1, to.getConta());
			stm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public ClienteTo carregar(String conta){
		ClienteTo to = new ClienteTo();
		System.out.println(to.getNome()+to.getAgencia());
		String sqlSelect = "SELECT nome, agencia FROM cliente WHERE cliente.conta = ?";
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setString(1, conta);
			try(ResultSet rs = stm.executeQuery();){
				if(rs.next()){
					to.setNome(rs.getString("nome"));
					to.setAgencia(rs.getString("agencia"));
					System.out.println(to.getNome()+to.getAgencia());
				}
				System.out.println(to.getNome()+to.getAgencia());
			}catch(SQLException e){
				e.printStackTrace();
			}
			
		}catch (SQLException e1) {
			e1.printStackTrace();
		}
		return to;
	}
	
	
	
	// Inclus�o, Consulta, Altera��o e Exclus�o - Sistema

	/*public String consultarSaldo(ClienteTo to) {
		String sqlSelect = "SELECT * FROM saldo WHERE conta = ? and data_saldo = ?";
		ResultSet rs = null;
		String sA = "";

		try (Connection conn = ConnectionFactory.obtemConexao();
			PreparedStatement stm = conn.prepareStatement(sqlSelect);){
			stm.setString(1, to.getConta());
			stm.setString(2, sData);
			rs = stm.executeQuery();
			while (rs.next()) {
				sA = rs.getString("saldo");
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sA;
	}

	/*public String consultarSaldoSolo(Connection conn, String cont) {
		String sqlSelect = "SELECT * FROM saldo WHERE conta = ? order by data_saldo";
		PreparedStatement stm = null;
		ResultSet rs = null;
		String sConta = cont;
		String sA = "";

		try {
			stm = conn.prepareStatement(sqlSelect);
			stm.setString(1, sConta);
			rs = stm.executeQuery();
			while (rs.next()) {
				sA = rs.getString("saldo");
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(sA);
		return sA;
	}

	public void Sacar(Connection conn, String cont, double valor) {
		String valorConta = consultarSaldoSolo(conn, cont);
		double valorContaD = Double.parseDouble(valorConta);
		if (valor > valorContaD) {
			JOptionPane.showMessageDialog(null, "Saldo Insuficiente!");
		} else {
			// double resultadoSaldo = valorContaD - valor;
			// updateSaldo(conn, cont, resultadoSaldo);
			JOptionPane.showMessageDialog(null, " Saque efetuado! Retire as C�dulas!");
		}

	}

	public void debAuto(Connection conn, String serv, String oper, String dat, String consum) {
		String sServ = "1";
		String sOper = oper;
		String sData = dat;
		String sConsum = consum;
		PreparedStatement stm = null;
		String sqlInsert = "INSERT INTO debauto(servico, operadora, data_deb, consumidor) VALUES(?, ?, ?, ?)";

		try {
			stm = conn.prepareStatement(sqlInsert);
			stm.setString(1, sServ);
			stm.setString(2, sOper);
			stm.setString(3, sData);
			stm.setString(4, sConsum);
			stm.executeUpdate();
			conn.commit();

			stm.close();
			System.out.println("OK");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void transferir(Connection conn, String age, String con, double valor) {
		String sAg = age;
		String sCon = con;
		double dValor = valor;
		String sqlInsert = "INSERT INTO transferencia(agencia,conta,valor, id_transf) VALUES (?, ?, ?, ?)";
		int idTrans = 1;
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sqlInsert);
			stm.setString(1, sAg);
			stm.setString(2, sCon);
			stm.setDouble(3, dValor);
			stm.setInt(4, idTrans);
			stm.execute();
			conn.commit();

			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("teste ");

	}

	public void extrato(Connection conn, String cont) {
		// id_operacao, cpf, valor, data_ext
		String conta = cont;

		String sqlSelect = "SELECT * FROM extrato where conta = ?";
		PreparedStatement stm = null;
		ResultSet rs = null;
		String sA = "****** Extrato ********\n";

		try {
			stm = conn.prepareStatement(sqlSelect);
			stm.setString(1, conta);
			rs = stm.executeQuery();
			while (rs.next()) {
				sA += "Data:  " + rs.getString("data_ext") + "\n";
				sA += "Saldo: " + rs.getString("saldo") + "\n";

			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		JOptionPane.showMessageDialog(null, sA);

	}

	public void InsertExtrato(Connection conn, double sal, String dataExt) {
		String sqlInsert = "INSERT INTO extrato(saldo , data_ext) VALUES(?,?)";
		PreparedStatement stm = null;

		String sData = dataExt;
		double dSaldo = sal;

		try {
			stm = conn.prepareStatement(sqlInsert);
			stm.setDouble(1, dSaldo);
			stm.setString(2, sData);
			stm.execute();

			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}*/
	

}
