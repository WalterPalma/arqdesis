package To;

public class ClienteTo
{
	private String nome;
	private String agencia, conta;
	
	
	//Nome
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	//Agencia
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	//Conta
	public String getConta(){
		return conta;
	}
	public void setConta(String conta){
		this.conta = conta;
	}

	//imprimir
	public String print() {
		String txt = "";
		txt += "Nome: 	 " + getNome() + "\n";
		txt += "Agencia: " + getAgencia() + "\n";
		txt += "Conta:	 " + getConta();
		return txt;
	}
}
