package To;

public class ConsultarSaldoTo  {

	private String conta;
	private String saldo, data;
	
	//Conta
	public String getConta(){
		return conta;
	}
	public void setConta(String conta){
		this.conta = conta;		
	}
	//Saldo
	public String getSaldo(){
		return saldo;
	}
	public void setSaldo(String saldo){
		this.saldo = saldo;
	}
	//Data
	public String getData(){
		return data;
	}
	public void setData(String data){
		this.data = data;
	}
	
	//imprimir 
	public String print()
	{
		String txt = "";
		txt += "Conta: " + getConta() + "\n";
		txt += "Saldo: " + getSaldo()+ "\n";
		txt += "Data: " + getData();
		return txt;
	}
}
