package model;

import DAO.ClienteDAO;
import DAO.ConsultarSaldoDAO;
import To.ClienteTo;
import To.ConsultarSaldoTo;
//import model.Cliente;

public class ConsultarSaldo{
	
	protected String data;
	protected String conta;
	//protected String saldo;
	
	public ConsultarSaldo (String conta, String data)
	{
		this.conta = conta;
		this.data = data;
		//this.saldo = saldo;
	}
	
	//Get's
	public String getConta(){
		return conta;
	}
	public String getData(){
		return data;
	}
	/*public String getSaldo(){
		return saldo;
	}	*/
	//Set's
	public void setData(String data){
		this.data = data;
	}
	/*public void setSaldo(String saldo){
		this.saldo = saldo;
	}*/
		
	//Carregar
	public void carregar() {

		ConsultarSaldoDAO dao = new ConsultarSaldoDAO();
		ConsultarSaldoTo to = new ConsultarSaldoTo();
		to.setConta(getConta());
		dao.consultarSaldo(to);
		data = to.getData();
	}
	
	@Override
	public String toString(){
		return "Conta=" + getConta() + ",Data= " + getData();
	}
	
	
	
	

}
