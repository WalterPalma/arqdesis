package model;

import java.io.File;
import java.util.Formatter;

import javax.swing.JOptionPane;

import DAO.ClienteDAO;
import To.ClienteTo;

public class Cliente {
	protected String nome;
	protected String agencia, conta;

	public Cliente(String nome, String agencia, String conta) {
		this.nome = nome;
		this.agencia = agencia;
		this.conta = conta;
	}

	// Nome 
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	// Agencia
	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	// Conta
	public String getConta() {
		return conta;
	}

	public void setConta(String conta) {
		this.conta = conta;
	}

	public void criar() {
		ClienteDAO dao = new ClienteDAO();
		ClienteTo to = new ClienteTo();
		to.setNome(nome);
		to.setAgencia(agencia);
		to.setConta(conta);
		dao.incluir(to);
	}

	public void atualizar() {
		ClienteDAO dao = new ClienteDAO();
		ClienteTo to = new ClienteTo();
		to.setNome(nome);
		to.setAgencia(agencia);
		to.setConta(conta);
		dao.atualizar(to);
	}

	public void excluir() {
		ClienteDAO dao = new ClienteDAO();
		ClienteTo to = new ClienteTo();
		to.setConta(conta);
		dao.excluir(to);
	}

	public void carregar() {
		ClienteDAO dao = new ClienteDAO();
		ClienteTo to = dao.carregar(conta);
		nome = to.getNome();
		agencia = to.getAgencia();
	}

	@Override
	public String toString() {
		return "Cliente [nome=" + nome + ", agencia=" + agencia + ",conta=" + conta + "]";
	}

	// ----------------------------------------------------------------------

	// Salvar em TXT

	public void criarTxt() {

		String nomeArq = "Usuario " + conta + ".txt";
		System.out.println(nomeArq);
		// tentando criar arquivo
		try {
			Formatter saida = new Formatter(nomeArq);
			saida.format(toString());
			saida.close();

		} catch (Exception erro) {
			JOptionPane.showMessageDialog(null, "Arquivo nao pode ser gerado!", "Erro", 0);
		}

	}


	public String[] descripto() {

		Leitor read = new Leitor();
		String str = read.lerArquivo();

		String user[] = str.split(",");

		long vet[] = new long[4];
		for (int i = 0; i < vet.length; i++) {
			vet[i] = Long.parseLong(user[i]);
		}

		return user;
	}

	public int buscaBinaria(String[] vetor, long busca) {
		int inicio, meio, fim, resultado;

		inicio = 0;
		fim = vetor.length - 1;
		resultado = -1;

		while (inicio <= fim) {
			meio = (inicio + fim) / 2;

			if (Long.parseLong(vetor[meio].substring(0, 10)) == busca) {
				resultado = meio;
				inicio = (fim + 1);
			} else {
				if (Long.parseLong(vetor[meio].substring(0, 10)) > busca) {
					fim = meio - 1;
				} else {
					inicio = meio + 1;
				}
			}
		}

		return resultado;
	}

	public String cripto() throws Exception {

		Leitor read = new Leitor();
		String str = read.lerArquivo();
		// System.out.println(str);

		String sMsgClara = str;
		String sMsgCifrada = null;
		String msg = "";
		byte[] bMsgClara = null;
		byte[] bMsgCifrada = null;
		// Instancia objeto da classe Impressora
		Impressora prn = new Impressora();
		// Converte o texto String dado no equivalente byte[]
		bMsgClara = sMsgClara.getBytes("ISO-8859-1");
		// Imprime o texto original em String
		// System.out.println(msg);
		CryptoAES caes = new CryptoAES();
		caes.geraChave(new File("chave.simetrica"));
		caes.geraCifra(bMsgClara, new File("chave.simetrica"));
		bMsgCifrada = caes.getTextoCifrado();
		// sMsgCifrada = (new String (bMsgCifrada, "ISO-8859-1"));
		sMsgCifrada = (prn.hexBytesToString(bMsgCifrada));
		msg += sMsgCifrada;

		criaTxt c = new criaTxt();
		c.cria(msg);

		return msg;
	}

}
