package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class Leitor
{

   public String lerArquivo()
   {
      try 
      {
         File f = new File("texto_decifrado.txt");
         String caminho = f.getAbsolutePath();
         
         BufferedReader in = new BufferedReader(new FileReader(caminho));
         String str;
         StringBuffer buf = new StringBuffer();
         while (in.ready()) {
            str = in.readLine();
            buf.append(str);
         }
         in.close();
         return buf.toString();
      } 
      catch (IOException e) {
         e.printStackTrace();
         return null;
      }
   }
}

