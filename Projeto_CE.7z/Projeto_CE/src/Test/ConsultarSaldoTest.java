package Test;

import DAO.ConsultarSaldoDAO;
import To.ConsultarSaldoTo;

public class ConsultarSaldoTest {
	
	public static void main(String args[]){
		
		ConsultarSaldoTo consulta = new ConsultarSaldoTo();
		consulta.setConta("292427");
	
		ConsultarSaldoDAO cons = new ConsultarSaldoDAO();
		
		System.out.println(cons.consultarSaldo(consulta));
		
		
	}

}
